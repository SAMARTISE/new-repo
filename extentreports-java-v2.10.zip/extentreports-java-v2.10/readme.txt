If you have used any of the the 2.10-beta version:

In your target directory where you store your results, delete extent.db before starting to use the new version of the jar.  

There have been several changes to the db structure and using the old db format will cause exceptions.

If you have not used any of the beta version, or do not see "extent.db" in any location, disregard this readme.